# PHP Classes

In the following some classes are described which are considered very useful for use in theme code at times. It may end up saving you a lot of time.

All PHP scripts are really plug and play. Also, it is unlikely to produce any errors even if you have included some of the classes already in your theme or use a plugin which integrates these classes. See the respective documentation of the scripts.

* [Aqua Resizer][Aqua Resizer] for image thumbnail generation - by Syamil MJ
* [TGM Plugin Activation][TGM Plugin Activation] require and recommend plugins for themes - by Thomas Griffin

[Aqua Resizer]: https://github.com/syamilmj/Aqua-Resizer/
[TGM Plugin Activation]: https://github.com/thomasgriffin/TGM-Plugin-Activation