# Function Reference

## inferno_preview()

### Description

Wrapper function for [`Inferno_Preview()`][class_inferno_preview] class


[class_inferno_preview]: .manual_root/PHP_API/Class_Reference/#Inferno_Preview